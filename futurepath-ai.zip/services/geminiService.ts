import { GoogleGenAI, Type, Modality, GenerateContentResponse, Chat } from "@google/genai";
import { CareerAnalysisResult } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// --- Schema Definitions for Structured Output ---

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    summary: { type: Type.STRING, description: "A comprehensive executive summary of the user's profile and potential (Max 3 sentences)." },
    careerPaths: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          reasoning: { type: Type.STRING, description: "Why this role fits the user." },
          matchScore: { type: Type.NUMBER, description: "0-100 match percentage" },
          existingStrengths: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING }, 
            description: "Key strengths the user already has for this role." 
          },
          requiredSkills: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING }, 
            description: "Essential skill categories required for this role." 
          }
        }
      }
    },
    skillGapAnalysis: {
      type: Type.OBJECT,
      properties: {
        existingSkills: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "CRITICAL: List 10+ technical and soft skills found in the input. If text is sparse, INFER skills from job titles or education."
        },
        missingSkills: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              skill: { type: Type.STRING },
              priority: { type: Type.STRING, enum: ['High', 'Medium', 'Low'] },
              reason: { type: Type.STRING, description: "Why this skill matters for the recommended roles." },
              toolsOrTechnologies: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Specific tools, libraries, or technologies to learn."
              }
            }
          }
        }
      }
    },
    learningPlan: {
      type: Type.OBJECT,
      properties: {
        week1: {
          type: Type.OBJECT,
          properties: {
            goal: { type: Type.STRING, description: "The main learning objective for Week 1" },
            tasks: {
              type: Type.ARRAY,
              items: { type: Type.OBJECT, properties: { day: { type: Type.STRING }, task: { type: Type.STRING }, resource: { type: Type.STRING } } }
            }
          }
        },
        week2: {
          type: Type.OBJECT,
          properties: {
            goal: { type: Type.STRING, description: "The main learning objective for Week 2" },
            tasks: {
              type: Type.ARRAY,
              items: { type: Type.OBJECT, properties: { day: { type: Type.STRING }, task: { type: Type.STRING }, resource: { type: Type.STRING } } }
            }
          }
        },
        week3: {
          type: Type.OBJECT,
          properties: {
            goal: { type: Type.STRING, description: "The main learning objective for Week 3" },
            tasks: {
              type: Type.ARRAY,
              items: { type: Type.OBJECT, properties: { day: { type: Type.STRING }, task: { type: Type.STRING }, resource: { type: Type.STRING } } }
            }
          }
        },
        week4: {
          type: Type.OBJECT,
          properties: {
            goal: { type: Type.STRING, description: "The main learning objective for Week 4" },
            tasks: {
              type: Type.ARRAY,
              items: { type: Type.OBJECT, properties: { day: { type: Type.STRING }, task: { type: Type.STRING }, resource: { type: Type.STRING } } }
            }
          }
        }
      }
    },
    interviewPrep: {
      type: Type.OBJECT,
      properties: {
        hr: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { question: { type: Type.STRING }, answerKey: { type: Type.STRING } } } },
        technical: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { question: { type: Type.STRING }, answerKey: { type: Type.STRING } } } },
        behavioral: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { question: { type: Type.STRING }, answerKey: { type: Type.STRING } } } }
      }
    },
    resumeTips: {
      type: Type.ARRAY,
      items: { type: Type.STRING }
    },
    improvedResumePoints: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of rewritten, strong, professional, ATS-friendly resume bullet points based on the user's experience."
    },
    portfolioProjects: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING, description: "What the project does." },
          skillsDemonstrated: { type: Type.ARRAY, items: { type: Type.STRING } },
          whyItHelps: { type: Type.STRING, description: "Why this project helps the user get hired." }
        }
      }
    }
  }
};

// --- Helper for Retries ---

async function retryOperation<T>(operation: () => Promise<T>, maxAttempts: number = 3, delayMs: number = 1000): Promise<T> {
  let lastError: any;
  
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      if (!apiKey) throw new Error("API Key is missing. Please check your configuration.");
      return await operation();
    } catch (error: any) {
      lastError = error;
      console.warn(`Attempt ${attempt} failed:`, error);
      
      // Retry on network errors (fetch failed) or 5xx server errors
      const isRetryable = 
        error.message?.includes('fetch') || 
        error.message?.includes('xhr') || 
        error.message?.includes('network') ||
        (error.status && error.status >= 500);

      if (!isRetryable || attempt === maxAttempts) {
        throw error;
      }
      
      // Exponential backoff
      await new Promise(resolve => setTimeout(resolve, delayMs * Math.pow(2, attempt - 1)));
    }
  }
  throw lastError;
}

// --- API Functions ---

export const analyzeProfile = async (
  textInput: string, 
  imageBase64?: string
): Promise<CareerAnalysisResult> => {
  
  const parts: any[] = [];
  if (imageBase64) {
    parts.push({
      inlineData: {
        mimeType: 'image/jpeg', 
        data: imageBase64
      }
    });
  }
  if (textInput) {
    parts.push({ text: textInput });
  }

  const prompt = `
    You are FuturePath AI. Analyze the provided user profile (resume text, bio, or image of a resume).
    
    STEP 1: COMPREHENSIVE SKILL EXTRACTION (MANDATORY)
    - EXTRACT every single technical skill, soft skill, tool, language, framework, and certification mentioned.
    - LOOK DEEPER: If the user says "Computer Science Student", INFER skills like "Algorithms", "Data Structures", "Java", "C++" if not explicitly listed.
    - YOU MUST populate the 'existingSkills' field in 'skillGapAnalysis' with AT LEAST 8-10 items. Do not leave this empty.
    
    STEP 2: ANALYSIS & RECOMMENDATIONS
    1. Recommend 3-4 ideal career paths.
       For each path, you MUST provide:
       - Title
       - Reasoning: Why this role fits the user.
       - Existing Strengths: Key strengths the user already has for this role.
       - Required Skills: Essential skill categories required for this role.
       - Match Score: 0-100%.
    2. Perform a Structured Skill Gap Analysis.
       - Existing Skills: Populate this with the comprehensive list from Step 1.
       - Missing Skills: List skills the user needs to learn.
         For each missing skill, provide:
         - Priority (High/Medium/Low)
         - Reason (Why it matters)
         - Tools/Technologies (Specific tools to learn)
    3. Generate a 30-day learning plan.
       - Break down into 4 weeks.
       - For EACH week, provide a clear 'goal' and daily 'tasks'.
    4. Create an Interview Prep Pack.
       - 5 HR Questions + Answers.
       - 5 Technical Questions (based on recommended roles) + Answers.
       - 3 Behavioral (STAR) Questions + Answers.
    5. Resume Improvements.
       - Provide general resume tips.
       - REWRITE 3-5 of the user's implicit or explicit experience points into strong, ATS-friendly bullet points using "Action Verb + Task + Result" format.
    6. Suggest portfolio projects (MANDATORY).
       - You MUST suggest exactly 3 projects, even for beginners.
       - Include what it does, skills built, and WHY it helps get hired.
    7. Summary.
       - Write a SHORT, CONCISE executive summary (Max 3 sentences).
    
    Think deeply about the connection between their current skills and the target roles.
  `;
  parts.push({ text: prompt });

  return retryOperation(async () => {
    // Gemini 2.5 Flash for speed while maintaining high quality output
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: analysisSchema,
        // Removed thinkingConfig to optimize for latency
      }
    });

    const jsonText = response.text || "{}";
    return JSON.parse(jsonText) as CareerAnalysisResult;
  });
};

export const getQuickTip = async (): Promise<string> => {
  if (!apiKey) return "Keep learning every day.";
  
  try {
    // Use Gemini 2.5 Flash Lite for fast, low-latency responses
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-lite',
      contents: "Give me one specific, high-value career tip for a modern professional. Focus on productivity, soft skills, or leadership. Avoid generic advice. Max 25 words.",
    });
    return response.text || "Keep learning every day.";
  } catch (e) {
    console.error("Quick tip failed", e);
    return "Stay curious and keep growing.";
  }
};

export { Chat };

export const streamChatResponse = async (
  history: { role: 'user' | 'model'; parts: { text: string }[] }[],
  newMessage: string,
  onChunk: (text: string) => void
) => {
  if (!apiKey) throw new Error("API Key missing");

  const chat = ai.chats.create({
    model: 'gemini-3-pro-preview', // Pro for high quality chat
    history: history,
    config: {
      systemInstruction: "You are FuturePath AI, a helpful and encouraging career mentor. Be concise but insightful."
    }
  });

  const result = await chat.sendMessageStream({ message: newMessage });
  for await (const chunk of result) {
    const c = chunk as GenerateContentResponse;
    if (c.text) {
      onChunk(c.text);
    }
  }
};

export const generateSpeech = async (text: string): Promise<string> => {
  if (!apiKey) throw new Error("API Key missing");

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-preview-tts',
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("No audio generated");
  return base64Audio;
};