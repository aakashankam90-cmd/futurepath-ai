import React, { useState } from 'react';
import { X, Mail, Phone, Lock, ArrowRight, Loader2, CheckCircle } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
}

type AuthMethod = 'phone' | 'email';
type AuthStep = 'input' | 'otp';

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
  const [method, setMethod] = useState<AuthMethod>('phone');
  const [step, setStep] = useState<AuthStep>('input');
  const [inputValue, setInputValue] = useState('');
  const [otpValue, setOtpValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSendCode = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation Logic
    if (method === 'phone') {
      // Remove all non-numeric characters for validation
      const digits = inputValue.replace(/\D/g, '');
      if (digits.length !== 10) {
        setError('Enter valid phone number');
        return;
      }
    } else if (method === 'email') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!inputValue || !emailRegex.test(inputValue)) {
        setError('Enter valid email address');
        return;
      }
    } else if (!inputValue) {
      setError('Please enter your details');
      return;
    }

    setError('');
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setStep('otp');
    }, 1500);
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otpValue.length < 4) {
      setError('Please enter a valid 4-digit code');
      return;
    }
    setError('');
    setIsLoading(true);

    // Simulate API verification
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300" 
        onClick={onClose}
      />

      {/* Modal Content */}
      <div className="relative bg-dark-900 border border-dark-700 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
        
        {/* Header */}
        <div className="bg-dark-800 p-6 border-b border-dark-700 flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold text-white mb-1">Save your progress</h2>
            <p className="text-gray-400 text-sm">Log in to analyze your resume and generate your personalized career path.</p>
          </div>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Tabs */}
          {step === 'input' && (
            <div className="flex gap-2 p-1 bg-dark-800 rounded-lg mb-6">
              <button
                onClick={() => { setMethod('phone'); setInputValue(''); setError(''); }}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all flex items-center justify-center gap-2
                  ${method === 'phone' ? 'bg-brand-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
              >
                <Phone className="w-4 h-4" /> Phone
              </button>
              <button
                onClick={() => { setMethod('email'); setInputValue(''); setError(''); }}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all flex items-center justify-center gap-2
                  ${method === 'email' ? 'bg-brand-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
              >
                <Mail className="w-4 h-4" /> Email
              </button>
            </div>
          )}

          {/* Form */}
          <form onSubmit={step === 'input' ? handleSendCode : handleVerify}>
            
            <div className="space-y-4">
              {step === 'input' ? (
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                    {method === 'phone' ? 'Phone Number' : 'Email Address'}
                  </label>
                  <div className="relative">
                    <input
                      type={method === 'phone' ? 'tel' : 'email'}
                      value={inputValue}
                      onChange={(e) => {
                        // For phone, allow digits, spaces, dashes, parens, plus
                        const val = e.target.value;
                        if (method === 'phone') {
                           if (/^[\d\s\-()+]*$/.test(val)) {
                             setInputValue(val);
                           }
                        } else {
                           setInputValue(val);
                        }
                      }}
                      placeholder={method === 'phone' ? '9876543210' : 'you@example.com'}
                      className="w-full bg-dark-800 border border-dark-600 rounded-lg py-3 px-4 pl-10 text-white focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all"
                      autoFocus
                    />
                    <div className="absolute left-3 top-3.5 text-gray-500">
                      {method === 'phone' ? <Phone className="w-5 h-5" /> : <Mail className="w-5 h-5" />}
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-3 leading-relaxed">
                    To analyze your resume and generate your personalized career path, please log in or sign up using your {method === 'phone' ? 'phone number' : 'email'}. This helps us securely save your results.
                  </p>
                </div>
              ) : (
                <div>
                  <div className="text-center mb-6">
                    <div className="w-12 h-12 bg-brand-900/30 rounded-full flex items-center justify-center mx-auto mb-3 text-brand-400">
                      <Lock className="w-6 h-6" />
                    </div>
                    <h3 className="text-white font-medium">Enter Verification Code</h3>
                    <p className="text-sm text-gray-400 mt-1">
                      We sent a code to <span className="text-white font-mono">{inputValue}</span>
                    </p>
                    <button 
                      type="button" 
                      onClick={() => { setStep('input'); setOtpValue(''); setError(''); }}
                      className="text-xs text-brand-400 hover:underline mt-2"
                    >
                      Change {method}
                    </button>
                  </div>

                  <div className="relative">
                    <input
                      type="text"
                      value={otpValue}
                      onChange={(e) => setOtpValue(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))}
                      placeholder="0000"
                      className="w-full bg-dark-800 border border-dark-600 rounded-lg py-3 px-4 text-center text-white text-2xl tracking-[0.5em] font-mono focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all"
                      autoFocus
                    />
                  </div>
                </div>
              )}

              {error && (
                <p className="text-red-400 text-sm flex items-center gap-1 animate-pulse">
                   <span className="w-1.5 h-1.5 rounded-full bg-red-500" /> {error}
                </p>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-brand-600 hover:bg-brand-500 text-white font-bold py-3 px-4 rounded-lg shadow-lg shadow-brand-500/20 transition-all flex items-center justify-center gap-2 mt-4"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : step === 'input' ? (
                  <>Send Code <ArrowRight className="w-4 h-4" /></>
                ) : (
                  <>Verify & Analyze <CheckCircle className="w-4 h-4" /></>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};