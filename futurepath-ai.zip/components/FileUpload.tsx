import React, { useRef, useState, useEffect } from 'react';
import { Upload, X, FileText, Image as ImageIcon, Mic, StopCircle } from 'lucide-react';

interface FileUploadProps {
  onDataReady: (text: string, imageBase64?: string) => void;
  isLoading: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onDataReady, isLoading }) => {
  const [text, setText] = useState('');
  const [fileName, setFileName] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | undefined>(undefined);
  const [isListening, setIsListening] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Resize and compress image before setting state
  const processImage = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        // Increased from 1024 to 1600 to ensure resume text is readable for OCR
        const maxDim = 1600; 

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);

        // Compress to JPEG with 0.7 quality to keep file size reasonable despite higher res
        const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
        const base64String = dataUrl.split(',')[1];
        setImageBase64(base64String);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      processImage(file);
    }
  };

  const clearFile = () => {
    setFileName(null);
    setImageBase64(undefined);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text && !imageBase64) return;
    onDataReady(text, imageBase64);
  };

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert("Voice-to-text is not supported in this browser.");
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      let newTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          newTranscript += event.results[i][0].transcript;
        }
      }
      if (newTranscript) {
        setText((prev) => {
          const separator = prev.length > 0 && !prev.endsWith(' ') ? ' ' : '';
          return prev + separator + newTranscript;
        });
      }
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      
      if (event.error === 'not-allowed' || event.error === 'permission-denied' || event.error === 'service-not-allowed') {
        alert("Microphone access is required for voice input. Please allow microphone permissions in your browser settings.");
      } else if (event.error === 'network') {
        alert("Network error occurred. Voice-to-text requires an internet connection.");
      }
      
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;
    
    try {
      recognition.start();
    } catch (e) {
      console.error("Failed to start recognition", e);
      setIsListening(false);
    }
  };

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  return (
    <form onSubmit={handleSubmit} className="bg-dark-800 p-6 rounded-2xl shadow-xl border border-dark-700">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <label className="block text-gray-300 text-sm font-semibold">
            Paste Resume / Skills Text
          </label>
          {isListening && (
            <span className="text-xs font-bold text-red-500 animate-pulse flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-red-500"></span> Listening...
            </span>
          )}
        </div>
        
        <div className="relative">
          <textarea
            className="w-full bg-dark-900 text-white rounded-lg border border-dark-700 p-4 focus:ring-2 focus:ring-brand-500 focus:outline-none transition-all resize-none h-32 pr-12"
            placeholder="I have 5 years of experience in..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <button
            type="button"
            onClick={toggleListening}
            className={`absolute bottom-3 right-3 p-2 rounded-full transition-all ${
              isListening 
                ? 'bg-red-500/20 text-red-500 hover:bg-red-500/30 ring-2 ring-red-500/50' 
                : 'bg-dark-800 text-gray-400 hover:bg-dark-700 hover:text-white border border-dark-600'
            }`}
            title={isListening ? "Stop Recording" : "Start Voice Dictation"}
          >
            {isListening ? <StopCircle className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>
        </div>
      </div>

      <div className="mb-6">
        <label className="block text-gray-300 text-sm font-semibold mb-2">
          Or Upload Resume Image / Screenshot
        </label>
        
        {!fileName ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-dark-600 rounded-lg p-8 flex flex-col items-center justify-center cursor-pointer hover:border-brand-500 hover:bg-dark-900/50 transition-all group"
          >
            <Upload className="w-8 h-8 text-gray-400 group-hover:text-brand-500 mb-2" />
            <p className="text-sm text-gray-400">Click to upload image (JPG, PNG)</p>
          </div>
        ) : (
          <div className="flex items-center justify-between bg-dark-900 p-4 rounded-lg border border-dark-700">
            <div className="flex items-center gap-3">
              <ImageIcon className="w-5 h-5 text-brand-500" />
              <span className="text-sm text-white truncate max-w-[200px]">{fileName}</span>
            </div>
            <button 
              type="button" 
              onClick={clearFile}
              className="p-1 hover:bg-dark-800 rounded-full transition-colors"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        )}
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          accept="image/*" 
          className="hidden" 
        />
      </div>

      <button
        type="submit"
        disabled={isLoading || (!text && !imageBase64)}
        className={`w-full py-3 px-6 rounded-lg font-bold text-white transition-all flex items-center justify-center gap-2
          ${isLoading || (!text && !imageBase64)
            ? 'bg-dark-700 cursor-not-allowed text-gray-500' 
            : 'bg-brand-600 hover:bg-brand-500 shadow-lg hover:shadow-brand-500/20 active:scale-[0.98]'
          }`}
      >
        {isLoading ? (
          <>
            <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Analyzing Profile...
          </>
        ) : (
          <>
            <FileText className="w-5 h-5" />
            Generate Career Path
          </>
        )}
      </button>
    </form>
  );
};