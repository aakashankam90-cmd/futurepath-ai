
import React from 'react';
import { House, MessageSquare, Settings, User } from 'lucide-react';
import { FeatureMode } from '../types';

interface BottomNavProps {
  currentMode: FeatureMode;
  onNavigate: (mode: FeatureMode) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentMode, onNavigate }) => {
  const navItems = [
    { mode: FeatureMode.ANALYSIS, icon: House, label: 'Home' },
    { mode: FeatureMode.CHAT, icon: MessageSquare, label: 'AI Mentor' },
    { mode: FeatureMode.SETTINGS, icon: Settings, label: 'Settings' },
    { mode: FeatureMode.PROFILE, icon: User, label: 'Profile' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-dark-950/90 backdrop-blur-lg border-t border-dark-800 pb-safe pt-3 px-6 z-50 md:hidden pb-4">
      <div className="flex justify-between items-center">
        {navItems.map((item) => {
          const isActive = currentMode === item.mode;
          return (
            <button
              key={item.label}
              onClick={() => onNavigate(item.mode)}
              className={`flex flex-col items-center gap-1.5 transition-all w-16 group ${
                isActive ? 'text-brand-400' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <div className={`p-1 rounded-xl transition-colors ${isActive ? 'bg-brand-500/10' : ''}`}>
                <item.icon className={`w-6 h-6 ${isActive ? 'fill-brand-500/20' : ''} transition-transform group-active:scale-95`} />
              </div>
              <span className="text-[10px] font-medium tracking-wide">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
