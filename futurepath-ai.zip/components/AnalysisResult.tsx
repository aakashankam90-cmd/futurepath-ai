import React, { useState } from 'react';
import { CareerAnalysisResult } from '../types';
import { Play, Pause, ChevronDown, ChevronUp, Briefcase, AlertTriangle, Calendar, Award, MessageSquare, CheckCircle2, TrendingUp, Hammer, BookOpen, PenTool, Lightbulb, Circle } from 'lucide-react';
import { generateSpeech } from '../services/geminiService';

interface Props {
  data: CareerAnalysisResult;
}

export const AnalysisResult: React.FC<Props> = ({ data }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [activeTab, setActiveTab] = useState<'plan' | 'prep' | 'resume'>('plan');
  
  // State for tracking completed tasks (format: "weekKey-taskIndex")
  const [completedTasks, setCompletedTasks] = useState<Set<string>>(new Set());

  // Toast state
  const [toast, setToast] = useState<{message: string, visible: boolean}>({ message: '', visible: false });

  const showToast = (message: string) => {
    setToast({ message, visible: true });
    setTimeout(() => setToast(prev => ({ ...prev, visible: false })), 2000);
  };

  const handlePlaySummary = async () => {
    if (isPlaying) {
      audioContext?.suspend();
      setIsPlaying(false);
      return;
    }

    if (audioContext && audioContext.state === 'suspended') {
      audioContext.resume();
      setIsPlaying(true);
      return;
    }

    try {
      setIsGeneratingAudio(true);
      const audioBase64 = await generateSpeech(data.summary || "Summary not available");
      
      const binaryString = window.atob(audioBase64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      // Raw PCM decoding (16-bit signed, 1 channel, 24kHz)
      const pcm16 = new Int16Array(bytes.buffer);
      const audioBuffer = ctx.createBuffer(1, pcm16.length, 24000);
      const channelData = audioBuffer.getChannelData(0);
      for (let i = 0; i < pcm16.length; i++) {
        channelData[i] = pcm16[i] / 32768.0;
      }

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.onended = () => setIsPlaying(false);
      source.start(0);
      
      setAudioContext(ctx);
      setIsPlaying(true);
    } catch (error) {
      console.error("Audio generation failed", error);
      alert("Could not play audio. The browser might not support this format.");
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  const toggleTask = (week: string, index: number) => {
    const taskId = `${week}-${index}`;
    const newCompleted = new Set(completedTasks);
    let isCompleting = false;

    if (newCompleted.has(taskId)) {
      newCompleted.delete(taskId);
    } else {
      newCompleted.add(taskId);
      isCompleting = true;
    }
    setCompletedTasks(newCompleted);
    
    // Trigger toast
    if (isCompleting) {
      showToast("Task Completed! Great job.");
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-8">
      
      {/* Toast Notification */}
      <div className={`fixed bottom-20 left-1/2 transform -translate-x-1/2 z-50 transition-all duration-300 ${toast.visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}>
        <div className="bg-brand-600 text-white px-6 py-2 rounded-full shadow-lg font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          {toast.message}
        </div>
      </div>

      {/* Summary Section */}
      <div className="bg-gradient-to-r from-brand-900 to-dark-900 p-8 rounded-2xl border border-brand-700/50 shadow-2xl relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-2xl font-bold text-white">Career Profile Summary</h2>
            <button
              onClick={handlePlaySummary}
              disabled={isGeneratingAudio}
              className="flex items-center gap-2 bg-brand-600 hover:bg-brand-500 text-white px-4 py-2 rounded-full text-sm font-medium transition-all"
            >
              {isGeneratingAudio ? (
                <span className="animate-pulse">Loading Audio...</span>
              ) : isPlaying ? (
                <><Pause className="w-4 h-4" /> Pause</>
              ) : (
                <><Play className="w-4 h-4" /> Listen</>
              )}
            </button>
          </div>
          <p className="text-gray-300 leading-relaxed text-lg">{data.summary || "Analysis complete."}</p>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-500/10 blur-3xl rounded-full -mr-20 -mt-20"></div>
      </div>

      {/* Career Paths */}
      <div>
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-brand-400" />
          Recommended Career Paths
        </h3>
        
        {/* Horizontal scroll container on mobile, grid on desktop */}
        <div className="flex md:grid md:grid-cols-3 gap-4 md:gap-6 overflow-x-auto md:overflow-visible pb-4 md:pb-0 snap-x snap-mandatory -mx-6 px-6 md:mx-0 md:px-0 scrollbar-hide">
          {(data.careerPaths || []).map((path, idx) => (
            <div key={idx} className="min-w-[85vw] md:min-w-0 flex-shrink-0 snap-center bg-dark-800 p-5 md:p-6 rounded-xl border border-dark-700 hover:border-brand-500/50 transition-all group flex flex-col h-full">
              <div className="flex justify-between items-start mb-3">
                <div className="bg-brand-900/50 p-2.5 rounded-lg group-hover:bg-brand-600 transition-colors">
                  <Briefcase className="w-5 h-5 md:w-6 md:h-6 text-brand-400 group-hover:text-white" />
                </div>
                <span className="bg-green-900/30 text-green-400 px-2.5 py-1 rounded-full text-xs font-bold border border-green-800 whitespace-nowrap">
                  {path.matchScore}% Match
                </span>
              </div>
              
              <h3 className="text-lg md:text-xl font-bold text-white mb-2 line-clamp-2">{path.title}</h3>
              <p className="text-gray-400 text-sm mb-4 flex-grow line-clamp-4">{path.reasoning}</p>
              
              <div className="space-y-3 pt-4 border-t border-dark-700 mt-auto">
                {path.existingStrengths && path.existingStrengths.length > 0 && (
                  <div>
                    <p className="text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-brand-500" /> Your Strengths
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {(path.existingStrengths || []).slice(0, 3).map((s, i) => (
                        <span key={i} className="px-2 py-0.5 bg-brand-900/20 text-brand-300 border border-brand-900/40 rounded text-[10px] font-medium truncate max-w-[120px]">
                          {s}
                        </span>
                      ))}
                      {(path.existingStrengths?.length || 0) > 3 && (
                        <span className="px-1.5 py-0.5 text-gray-500 text-[10px] self-center">+{path.existingStrengths.length - 3}</span>
                      )}
                    </div>
                  </div>
                )}
                
                {path.requiredSkills && path.requiredSkills.length > 0 && (
                  <div>
                    <p className="text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 text-amber-500" /> Required Skills
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {(path.requiredSkills || []).slice(0, 3).map((s, i) => (
                        <span key={i} className="px-2 py-0.5 bg-dark-700 text-gray-400 border border-dark-600 rounded text-[10px] truncate max-w-[120px]">
                          {s}
                        </span>
                      ))}
                       {(path.requiredSkills?.length || 0) > 3 && (
                        <span className="px-1.5 py-0.5 text-gray-500 text-[10px] self-center">+{path.requiredSkills.length - 3}</span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Skill Gaps Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Existing Skills */}
        <div className="bg-dark-800 rounded-xl border border-dark-700 p-6">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            Skills You Have
          </h3>
          <div className="flex flex-wrap gap-2">
            {(data.skillGapAnalysis?.existingSkills || []).map((skill, idx) => (
              <span key={idx} className="bg-green-900/20 text-green-400 px-3 py-1.5 rounded-lg text-sm border border-green-900/30">
                {skill}
              </span>
            ))}
            {(!data.skillGapAnalysis?.existingSkills || data.skillGapAnalysis.existingSkills.length === 0) && (
              <span className="text-gray-500 text-sm italic">No specific skills identified yet.</span>
            )}
          </div>
          <p className="text-sm text-gray-500 mt-4 italic">
            These skills provide a strong foundation for your recommended career paths.
          </p>
        </div>

        {/* Missing Skills */}
        <div className="lg:col-span-2 bg-dark-800 rounded-xl border border-dark-700 overflow-hidden">
          <div className="p-6 border-b border-dark-700">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-brand-400" />
              Skills to Build
            </h3>
          </div>
          <div className="divide-y divide-dark-700">
            {(data.skillGapAnalysis?.missingSkills || []).map((gap, idx) => (
              <div key={idx} className="p-6 hover:bg-dark-700/50 transition-colors">
                <div className="flex justify-between items-start gap-4 mb-2">
                  <h4 className="text-lg font-bold text-white">{gap.skill}</h4>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap
                    ${gap.priority === 'High' ? 'bg-red-900/30 text-red-400 border border-red-800' : 
                      gap.priority === 'Medium' ? 'bg-amber-900/30 text-amber-400 border border-amber-800' : 
                      'bg-blue-900/30 text-blue-400 border border-blue-800'}`}>
                    {gap.priority} Priority
                  </span>
                </div>
                <p className="text-gray-300 text-sm mb-3">{gap.reason}</p>
                {gap.toolsOrTechnologies && gap.toolsOrTechnologies.length > 0 && (
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs text-gray-500 font-semibold flex items-center gap-1">
                      <Hammer className="w-3 h-3" /> Tools:
                    </span>
                    {(gap.toolsOrTechnologies || []).map((tool, tIdx) => (
                      <span key={tIdx} className="text-xs bg-dark-900 text-gray-400 px-2 py-0.5 rounded border border-dark-600">
                        {tool}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs Section */}
      <div>
        <div className="flex gap-4 border-b border-dark-700 mb-6 overflow-x-auto">
          <button 
            onClick={() => setActiveTab('plan')}
            className={`pb-3 px-2 font-medium transition-colors whitespace-nowrap ${activeTab === 'plan' ? 'text-brand-400 border-b-2 border-brand-400' : 'text-gray-500 hover:text-gray-300'}`}
          >
            30-Day Plan
          </button>
          <button 
            onClick={() => setActiveTab('prep')}
            className={`pb-3 px-2 font-medium transition-colors whitespace-nowrap ${activeTab === 'prep' ? 'text-brand-400 border-b-2 border-brand-400' : 'text-gray-500 hover:text-gray-300'}`}
          >
            Interview Prep
          </button>
          <button 
            onClick={() => setActiveTab('resume')}
            className={`pb-3 px-2 font-medium transition-colors whitespace-nowrap ${activeTab === 'resume' ? 'text-brand-400 border-b-2 border-brand-400' : 'text-gray-500 hover:text-gray-300'}`}
          >
            Resume Improvements
          </button>
        </div>

        {activeTab === 'plan' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.entries(data.learningPlan || {}).map(([week, weekData]) => {
              // Calculate Progress
              const totalTasks = weekData?.tasks?.length || 0;
              const tasksCompleted = weekData?.tasks?.filter((_, i) => completedTasks.has(`${week}-${i}`)).length || 0;
              const progress = totalTasks > 0 ? (tasksCompleted / totalTasks) * 100 : 0;
              const isWeekComplete = progress === 100 && totalTasks > 0;

              return (
                <div key={week} className={`bg-dark-800 rounded-xl border transition-all p-6 flex flex-col h-full ${isWeekComplete ? 'border-brand-500/50 bg-brand-900/10' : 'border-dark-700'}`}>
                  
                  {/* Header & Progress */}
                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="text-lg font-bold text-brand-400 capitalize flex items-center gap-2">
                        <Calendar className="w-4 h-4" /> 
                        {week.replace(/(\d+)/, ' $1')}
                        {isWeekComplete && <span className="ml-2 text-xs bg-brand-500 text-white px-2 py-0.5 rounded-full">Completed!</span>}
                      </h4>
                      <span className="text-xs font-mono text-gray-400">{Math.round(progress)}%</span>
                    </div>
                    <div className="w-full bg-dark-900 rounded-full h-1.5 overflow-hidden">
                      <div 
                        className="bg-brand-500 h-1.5 rounded-full transition-all duration-500 ease-out" 
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Goal */}
                  <div className="mb-4 bg-dark-900/50 p-3 rounded-lg border border-dark-700">
                     <p className="text-xs text-brand-300 font-semibold uppercase tracking-wider mb-1">Weekly Goal</p>
                     <p className="text-gray-200 text-sm italic">"{weekData?.goal || 'Focus on learning'}"</p>
                  </div>

                  {/* Tasks */}
                  <ul className="space-y-3 flex-grow">
                    {(weekData?.tasks || []).map((t, i) => {
                      const taskId = `${week}-${i}`;
                      const isCompleted = completedTasks.has(taskId);

                      return (
                        <li 
                          key={i} 
                          onClick={() => toggleTask(week, i)}
                          className={`flex gap-3 p-2 rounded-lg transition-all cursor-pointer group select-none
                            ${isCompleted ? 'bg-dark-700/30' : 'hover:bg-dark-700/50'}`}
                        >
                          <div className={`flex-shrink-0 w-5 h-5 mt-0.5 rounded-full border flex items-center justify-center transition-all duration-300
                            ${isCompleted 
                              ? 'bg-brand-500 border-brand-500 text-white scale-100' 
                              : 'border-gray-500 text-transparent group-hover:border-brand-400 scale-90'}`}>
                            <CheckCircle2 className={`w-3.5 h-3.5 transition-transform ${isCompleted ? 'scale-100' : 'scale-0'}`} />
                          </div>
                          
                          <div className={isCompleted ? 'opacity-50' : 'opacity-100'}>
                            <div className="flex items-center gap-2">
                              <span className={`text-xs font-mono px-1.5 py-0.5 rounded bg-dark-900 border border-dark-700 ${isCompleted ? 'text-gray-500' : 'text-gray-400'}`}>
                                {t.day.replace(/[^\d]/g, 'Day ')}
                              </span>
                              {t.resource && (
                                <a 
                                  href="#" 
                                  onClick={(e) => e.stopPropagation()} 
                                  className="text-brand-500 hover:text-brand-400"
                                  title="View Resource"
                                >
                                  <Lightbulb className="w-3 h-3" />
                                </a>
                              )}
                            </div>
                            <p className={`text-sm mt-1 transition-all ${isCompleted ? 'text-gray-500 line-through decoration-gray-600' : 'text-gray-200'}`}>
                              {t.task}
                            </p>
                            {t.resource && !isCompleted && (
                               <p className="text-xs text-brand-500/80 mt-1 truncate max-w-[200px]">{t.resource}</p>
                            )}
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              );
            })}
             {(!data.learningPlan || Object.keys(data.learningPlan).length === 0) && (
               <div className="col-span-2 text-center text-gray-500 py-8">
                 Learning plan could not be generated at this time.
               </div>
             )}
          </div>
        )}

        {activeTab === 'prep' && (
          <div className="space-y-6">
             <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
               <h3 className="text-lg font-bold text-white mb-4">HR & General Questions</h3>
               <div className="space-y-4">
                 {(data.interviewPrep?.hr || []).map((q, i) => (
                   <div key={i} className="bg-dark-900/50 p-4 rounded-lg">
                     <p className="font-medium text-brand-300 mb-2">Q: {q.question}</p>
                     <p className="text-gray-400 text-sm">A: {q.answerKey}</p>
                   </div>
                 ))}
               </div>
             </div>
             <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
               <h3 className="text-lg font-bold text-white mb-4">Technical Questions</h3>
               <div className="space-y-4">
                 {(data.interviewPrep?.technical || []).map((q, i) => (
                   <div key={i} className="bg-dark-900/50 p-4 rounded-lg">
                     <p className="font-medium text-brand-300 mb-2">Q: {q.question}</p>
                     <p className="text-gray-400 text-sm">A: {q.answerKey}</p>
                   </div>
                 ))}
               </div>
             </div>
             <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
               <h3 className="text-lg font-bold text-white mb-4">Behavioral (STAR)</h3>
               <div className="space-y-4">
                 {(data.interviewPrep?.behavioral || []).map((q, i) => (
                   <div key={i} className="bg-dark-900/50 p-4 rounded-lg">
                     <p className="font-medium text-brand-300 mb-2">Q: {q.question}</p>
                     <p className="text-gray-400 text-sm">A: {q.answerKey}</p>
                   </div>
                 ))}
               </div>
             </div>
          </div>
        )}

        {activeTab === 'resume' && (
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
               <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                 <PenTool className="w-5 h-5 text-brand-400" /> ATS-Friendly Rewrites
               </h3>
               <p className="text-sm text-gray-500 mb-4">
                 Strong, action-oriented bullet points tailored to your experience.
               </p>
               <ul className="space-y-3">
                 {data.improvedResumePoints && data.improvedResumePoints.length > 0 ? (
                    data.improvedResumePoints.map((point, i) => (
                     <li key={i} className="flex gap-3 text-gray-200 text-sm bg-dark-900/50 p-3 rounded-lg border border-dark-700/50">
                       <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                       {point}
                     </li>
                   ))
                 ) : (
                   <p className="text-gray-500 italic">No specific rewrites generated.</p>
                 )}
               </ul>
             </div>

             <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
               <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                 <Award className="w-5 h-5 text-brand-400" /> General Tips
               </h3>
               <ul className="space-y-3">
                 {(data.resumeTips || []).map((tip, i) => (
                   <li key={i} className="flex gap-3 text-gray-300">
                     <div className="w-1.5 h-1.5 rounded-full bg-brand-500 mt-2 flex-shrink-0" />
                     {tip}
                   </li>
                 ))}
               </ul>
             </div>
           </div>
        )}
      </div>

      {/* Portfolio Projects */}
      <div className="bg-gradient-to-br from-purple-900/20 to-brand-900/20 rounded-2xl border border-white/10 p-8">
        <h3 className="text-2xl font-bold text-white mb-6">Recommended Portfolio Projects</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {(data.portfolioProjects || []).map((proj, i) => (
            <div key={i} className="bg-dark-800/80 p-6 rounded-xl border border-dark-700 hover:border-brand-500/30 transition-all">
              <h4 className="text-lg font-bold text-white mb-2">{proj.title}</h4>
              <p className="text-gray-400 text-sm mb-4">{proj.description}</p>
              
              {proj.whyItHelps && (
                <div className="mb-4 bg-dark-900/40 p-3 rounded-lg border border-dark-700/50">
                   <p className="text-xs text-brand-400 font-bold uppercase tracking-wide mb-1 flex items-center gap-1">
                     <TrendingUp className="w-3 h-3" /> Why it helps
                   </p>
                   <p className="text-gray-300 text-xs leading-relaxed">{proj.whyItHelps}</p>
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                {(proj.skillsDemonstrated || []).map((skill, si) => (
                  <span key={si} className="text-xs bg-dark-900 text-gray-300 px-2 py-1 rounded border border-dark-700">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};